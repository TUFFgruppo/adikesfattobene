@echo off
REM Compila i sorgenti di src\ dentro build\ e avvia il server.
cd /d "%~dp0"
if not exist build mkdir build
javac -d build src\*.java
if errorlevel 1 (
    echo Compilazione fallita: controlla che javac sia nel PATH.
    pause
    exit /b 1
)
java -cp build Server
pause
