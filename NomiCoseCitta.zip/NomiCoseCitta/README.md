# Nomi-Cose-Citta (Java, in rete)

Gioco a round in stile "Nomi, Cose, Città": il server estrae una lettera, tutti
scrivono una parola per ogni categoria, il primo che riempie la tabella dice
`STOP` e si assegnano i punti.

## Struttura della cartella

```
NomiCoseCitta/
├── src/
│   ├── Server.java        server: accetta i client e avvia un thread di gioco per ognuno
│   ├── Client.java        client: intro, connessione, lettura messaggi, invio comandi
│   └── Gioco.java         corpo del gioco: round, lettere, timer, punteggi, classifica
├── icone/
│   ├── server.png          icona del server (1024x1024)
│   ├── server.ico          stessa icona in formato Windows (16-256 px)
│   ├── client.png          icona del client (1024x1024)
│   └── client.ico          stessa icona in formato Windows (16-256 px)
├── avvia-server.sh        compila e avvia il server (Linux/macOS)
├── avvia-client.sh        compila e avvia il client (Linux/macOS)
├── avvia-server.bat       compila e avvia il server (Windows)
├── avvia-client.bat       compila e avvia il client (Windows)
└── crea-scorciatoie.ps1   crea sul Desktop le scorciatoie Server/Client con le icone (Windows)
```

La cartella `build/` con i `.class` viene creata al primo avvio: si può
cancellare quando si vuole, viene ricompilata dagli script.

## Requisiti

- JDK 11 o successivo (`javac -version` deve rispondere). Il codice usa solo il
  JDK: nessuna libreria esterna.
- Per il video di introduzione (facoltativo): `ffplay` (ffmpeg), `mpv` o VLC e la
  variabile d'ambiente `INTRO_PLAYER` che punta al player.

## Avvio

Linux/macOS:

```
chmod +x avvia-server.sh avvia-client.sh
./avvia-server.sh
./avvia-client.sh
```

Windows: doppio clic su `avvia-server.bat` e `avvia-client.bat` (oppure le
scorciatoie create con `crea-scorciatoie.ps1`).

Compilare a mano, se serve:

```
javac -d build src/*.java
java -cp build Server
java -cp build Client
```

## Giocare in due

1. Un PC fa da server: avvia `avvia-server` e annota l'IP che stampa, ad esempio
   `[Server in ascolto su 192.168.1.20:7777]`.
2. Ogni giocatore avvia il client e inserisce prima la porta `7777`, poi quell'IP.
3. Il primo collegato è quello che comanda: quando siete in due scrive `START`.
4. A ogni round arrivano `ROUND n/5`, `LETTERA X` e `TEMPO 60`. Ognuno scrive una
   riga per casella (`Nomi=bruno`, `Cose=borsa`, ...); chi riempie tutto scrive
   `STOP` e chiude il round per tutti, altrimenti scade il timer.
5. Punteggi: 2 punti per una parola che nessun altro ha scritto, 1 se la scrive
   anche un altro, 0 se la casella è vuota o la parola non inizia con la lettera.
6. Dopo 5 round arriva la classifica; il primo giocatore può scrivere `START` per
   ricominciare.

### Due giocatori sullo stesso PC

Il client si lega alla porta locale 2555, quindi due istanze sullo stesso PC si
scontrano. Basta togliere queste tre righe da `src/Client.java` (la porta locale
non serve al gioco: il server riconosce i giocatori da IP e porta della
connessione):

```java
final int PORTA_CLIENTE = 2555;
socketCliente.setReuseAddress(true);
socketCliente.bind(new InetSocketAddress(InetAddress.getLocalHost().getHostAddress(), PORTA_CLIENTE));
```

Poi si lanciano due client con IP `127.0.0.1`.

## Comandi del client

| Comando | Effetto |
|---|---|
| `START` | avvia la partita (solo il primo giocatore, minimo 2 giocatori) |
| `CATEGORIE Nomi,Cose,Citta` | sceglie le colonne prima di partire (solo il primo giocatore, 2-8 categorie) |
| `Nomi=luca` | riempie una casella; `Nomi=` la svuota |
| `STOP` | chiude il round se tutte le caselle sono piene |
| `AIUTO` | elenco dei comandi |

## Protocollo (per chi costruisce l'interfaccia grafica)

Una riga di testo per messaggio, UTF-8, in entrambe le direzioni.

Dal server:

```
[Gioco] ...                                  messaggi informativi ed errori
ROUND 2/5                                    numero del round
LETTERA B                                    lettera estratta
TEMPO 60                                     secondi a disposizione
=== Round 2/5 (lettera B) ===                inizio riepilogo
- 127.0.0.1:51234: Nomi=bruno(2) Cose=borsa(1) Citta=-(0) -> 3 punti
CLASSIFICA
1. 127.0.0.1:51234 - 12 punti
```

Dal client: `START`, `STOP`, `AIUTO`, `CATEGORIE A,B,C`, `Categoria=parola`.

## Icone

`icone/server.png`, `icone/client.png` (1024x1024) e le versioni `.ico`
multirisoluzione per Windows.

- **Windows**: esegui `crea-scorciatoie.ps1`; crea sul Desktop `Server.lnk` e
  `Client.lnk` con l'icona giusta, così compare anche nella barra delle
  applicazioni. In alternativa: tasto destro sulla scorciatoia → Proprietà →
  Cambia icona → scegli il `.ico`.
- **Linux**: un file `.desktop` con `Icon=/percorso/NomiCoseCitta/icone/server.png`
  e `Exec=/percorso/NomiCoseCitta/avvia-server.sh` (idem per il client).
- Se in futuro il gioco avrà una finestra grafica, l'icona si può caricare in
  codice con `ImageIO.read(new File("icone/client.png"))` e `setIconImage(...)`.

## Note

- La partita parte solo con almeno 2 giocatori; chi si collega a partita iniziata
  entra subito e parte da 0 punti.
- Se esce il primo giocatore, il comando passa al primo rimasto e il server lo
  annuncia a tutti.
- Il server ascolta solo sull'IP della macchina (porta 7777): su Windows va
  concessa l'autorizzazione al firewall sulla rete privata, e i due PC devono
  essere sulla stessa rete.
