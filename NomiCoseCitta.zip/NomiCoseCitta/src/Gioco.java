import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Corpo del gioco Nomi-Cose-Citta, un thread per ogni client.
 *
 * Svolgimento:
 * 1) preparazione: i client si collegano e ricevono le categorie (le colonne
 *    della tabella), che il primo giocatore puo cambiare;
 * 2) estrazione: il server estrae una lettera a caso;
 * 3) svolgimento: ogni client manda una riga per casella, il piu velocemente
 *    possibile, finche il round e aperto;
 * 4) fine round: chi riempie tutte le caselle scrive STOP e il round si chiude
 *    per tutti, oppure scade il timer;
 * 5) punteggi: 2 punti per una parola che nessun altro ha scritto, 1 punto se
 *    la parola e condivisa, 0 se la casella e vuota o la parola non comincia
 *    con la lettera del round.
 *
 * Come e organizzato il codice:
 * - lo stato della partita (giocatori, round, lettera, timer) e STATICO e
 *   condiviso fra i thread: ogni accesso avviene dentro
 *   synchronized (Gioco.class), e mai un invio verso le socket, per non
 *   bloccare gli altri giocatori;
 * - lo stato del singolo giocatore (socket, nome, parole del round, punti) e
 *   un campo dell'oggetto, quindi ogni thread tocca solo il suo.
 *
 * Protocollo (una riga per messaggio, UTF-8).
 * Dal server:
 *   [Gioco] ...              messaggi informativi
 *   ROUND 2/5                numero del round
 *   LETTERA B                lettera estratta
 *   TEMPO 60                 secondi a disposizione
 *   === Round 2/5 (lettera B) ===
 *   - nome: Nomi=bruno(2) Cose=borsa(1) Citta=-(0) -> 3 punti
 *   CLASSIFICA / 1. nome - 12 punti
 * Dal client:
 *   START                    avvia la partita (solo il primo giocatore)
 *   CATEGORIE Nomi,Cose,...  sceglie le colonne prima di partire (solo il primo)
 *   Nomi=luca                riempie una casella (categoria=parola, vuota cancella)
 *   STOP                     chiude il round se tutte le caselle sono piene
 *   AIUTO                    elenco dei comandi
 *
 * Aggancio nel Server, subito dopo accept():
 * <pre>
 *     Gioco.avvia(ClientSock);
 * </pre>
 */
public class Gioco implements Runnable {

    /** Lettere estraibili: solo quelle che danno parole possibili in italiano. */
    private static final char[] ALFABETO = "ABCDEFGILMNOPRSTV".toCharArray();

    /** Numero di round di una partita. */
    private static final int ROUND_TOTALI = 5;

    /** Secondi per riempire la tabella in un round. */
    private static final int DURATA_ROUND = 60;

    /** Secondi fra un round e l'altro, per leggere i risultati. */
    private static final int PAUSA_FRA_ROUND = 10;

    /** Punti di una parola che nessun altro giocatore ha scritto. */
    private static final int PUNTI_PAROLA_UNICA = 2;

    /** Punti di una parola scritta anche da almeno un altro giocatore. */
    private static final int PUNTI_PAROLA_CONDIVISA = 1;

    /** Sotto questo numero di giocatori la partita non puo partire. */
    private static final int MIN_GIOCATORI = 2;

    /** Numero minimo di categorie scelte dal primo giocatore. */
    private static final int MIN_CATEGORIE = 2;

    /** Numero massimo di categorie scelte dal primo giocatore. */
    private static final int MAX_CATEGORIE = 8;

    /** Separatore di riga della piattaforma: i client leggono righe, non serve "\\n". */
    private static final String NL = System.lineSeparator();

    /** Risposta comune a ogni comando arrivato fuori da un round. */
    private static final String NESSUN_ROUND = "[Gioco] Nessun round in corso: aspetta la prossima lettera.";

    // ------------------------------------------------------------------
    // Stato della partita, condiviso fra i thread dei client.
    // Ogni accesso avviene dentro synchronized (Gioco.class).
    // ------------------------------------------------------------------

    /** Client in partita, in ordine di arrivo: il primo e quello che comanda. */
    private static final List<Gioco> GIOCATORI = new ArrayList<>();

    /** Colonne della tabella: le cinque di partenza, modificabili dal primo giocatore. */
    private static final List<String> CATEGORIE =
            new ArrayList<>(List.of("Nomi", "Cose", "Citta", "Animali", "Colori"));

    /** Lettere gia usate in questa partita, una dopo l'altra (String: indexOf basta). */
    private static String lettereUsate = "";

    /** True dalla START fino alla fine dell'ultimo round. */
    private static boolean partitaAvviata = false;

    /** True mentre i giocatori possono scrivere parole (fra l'apertura e la chiusura del round). */
    private static boolean roundAperto = false;

    /** Round in corso, da 1 a ROUND_TOTALI. */
    private static int roundCorrente = 0;

    /** Lettera del round in corso, maiuscola. */
    private static char lettera = 'A';

    /** Quando finisce il round in corso, in millisecondi (System.currentTimeMillis). */
    private static long fineRound = 0;

    /** Thread del timer del round, oppure della pausa prima del round successivo. */
    private static Thread timer;

    // ------------------------------------------------------------------
    // Stato del singolo giocatore.
    // ------------------------------------------------------------------

    /** Socket del client: da qui si leggono i comandi e si scrivono le risposte. */
    private final Socket socket;

    /** Nome del giocatore nella partita, nel formato "ip:porta". */
    private final String nome;

    /** Lettore dei comandi del client (UTF-8). */
    private BufferedReader input;

    /** Scrittore verso il client, con autoflush per non accumulare righe. */
    private PrintWriter output;

    /** Parole del round in corso: categoria -> parola scritta. */
    private final Map<String, String> parole = new HashMap<>();

    /** Punti totali del giocatore nella partita, azzerati a ogni nuova partita. */
    private int punti = 0;

    /**
     * Prepara il giocatore per una socket gia accettata dal server.
     *
     * @param socket connessione aperta con il client
     */
    private Gioco(Socket socket) {
        this.socket = socket;
        this.nome = nomeGiocatore(socket);
    }

    /**
     * Avvia il thread di gioco di un client: una chiamata per ogni accept().
     * Il thread e daemon, quindi non impedisce al server di terminare.
     *
     * @param client socket del client appena accettato
     */
    public static void avvia(Socket client) {
        Thread thread = new Thread(new Gioco(client), "gioco-" + nomeGiocatore(client));
        thread.setDaemon(true);
        thread.start();
    }

    /**
     * Nome del giocatore: indirizzo e porta del client. La porta della
     * connessione e diversa per ogni client, quindi il nome e unico.
     *
     * @param socket connessione del client
     * @return nome nel formato "ip:porta"
     */
    private static String nomeGiocatore(Socket socket) {
        InetAddress indirizzo = socket.getInetAddress();
        String ip = indirizzo == null ? "sconosciuto" : indirizzo.getHostAddress();
        return ip + ":" + socket.getPort();
    }

    // ------------------------------------------------------------------
    // Ciclo di gioco (un thread per client)
    // ------------------------------------------------------------------

    /**
     * Ciclo del singolo giocatore: apre gli stream, si presenta agli altri e
     * resta in attesa dei comandi finche il client non chiude la connessione.
     * All'uscita (anche per errore) il giocatore viene tolto dalla partita.
     */
    @Override
    public void run() {
        try {
            // UTF-8 scritto come stringa: evita di importare java.nio.charset.
            input = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            output = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);

            benvenuto();

            // readLine() restituisce null quando il client chiude la connessione.
            for (String riga = input.readLine(); riga != null; riga = input.readLine()) {
                gestisci(riga.trim());
            }
        } catch (IOException e) {
            System.out.println("[Gioco] Errore con il client " + nome + ": " + e.getMessage());
        } finally {
            // Sempre: il giocatore esce dalla lista, altrimenti il round non si
            // chiuderebbe piu aspettando le sue parole.
            abbandona();
            chiudi();
        }
    }

    /**
     * Prepara il client: lo registra nella partita, gli manda le categorie, le
     * istruzioni e, se serve, lo stato del round gia in corso.
     */
    private void benvenuto() {
        int totale;
        synchronized (Gioco.class) {
            GIOCATORI.add(this);
            totale = GIOCATORI.size();
        }
        // L'annuncio arriva anche a chi si e appena collegato: cosi vede subito
        // che la connessione funziona.
        trasmetti("[Gioco] " + nome + " e entrato in partita (" + totale + " giocatori).");

        invia("[Gioco] Categorie di questa partita: " + elencoCategorie());
        invia("[Gioco] Una casella per riga, ad esempio: Nomi=luca (riga vuota per cancellarla).");
        invia("[Gioco] Scrivi STOP quando hai riempito tutte le caselle.");
        invia("[Gioco] Punti: " + PUNTI_PAROLA_UNICA + " per parola unica, " + PUNTI_PAROLA_CONDIVISA
                + " se la scrive anche un altro, 0 se vuota o con la lettera sbagliata.");
        if (sonoHost()) {
            invia("[Gioco] Sei il primo giocatore: scrivi START per avviare la partita (minimo "
                    + MIN_GIOCATORI + " giocatori).");
        }

        // Chi entra a partita iniziata deve sapere lettera e tempo rimasto,
        // altrimenti non potrebbe giocare il round in corso.
        String stato = statoRound();
        if (!stato.isEmpty()) {
            invia(stato);
        }
    }

    /**
     * Esegue un comando arrivato dal client. Il protocollo e una riga di testo:
     * START, STOP, AIUTO, CATEGORIE ... oppure Categoria=parola.
     *
     * @param riga riga gia ripulita dagli spazi esterni
     */
    private void gestisci(String riga) {
        // Le righe vuote capitano premendo Invio: si ignorano in silenzio.
        if (riga.isEmpty()) {
            return;
        }
        // I comandi fissi si riconoscono senza badare a maiuscole/minuscole.
        String maiuscolo = riga.toUpperCase();
        int separatore = riga.indexOf('=');
        if (maiuscolo.equals("START")) {
            avviaPartita();
        } else if (maiuscolo.equals("STOP")) {
            fermaRound();
        } else if (maiuscolo.equals("AIUTO")) {
            aiuto();
        } else if (maiuscolo.startsWith("CATEGORIE")) {
            impostaCategorie(riga);
        } else if (separatore > 0) {
            // Formato "Categoria=parola": a sinistra la colonna, a destra il testo.
            salvaParola(riga.substring(0, separatore).trim(), riga.substring(separatore + 1).trim());
        } else {
            invia("[Gioco] Comando sconosciuto. Scrivi AIUTO per l'elenco dei comandi.");
        }
    }

    /** Manda al client l'elenco dei comandi disponibili. */
    private void aiuto() {
        invia("[Gioco] Comandi:");
        invia("  START              avvia la partita (solo il primo giocatore)");
        invia("  CATEGORIE A,B,C    sceglie le categorie prima di partire (solo il primo giocatore)");
        invia("  Categoria=parola   riempie una casella, es. Nomi=luca; vuota la cancella");
        invia("  STOP               chiude il round, se hai riempito tutte le caselle");
        invia("  AIUTO              questo elenco");
    }

    /**
     * Salva una parola nel round in corso; una parola vuota cancella la casella.
     * Rifiuta le parole che non cominciano con la lettera del round.
     *
     * @param categoriaRichiesta nome della colonna scritto dal client
     * @param parola            parola scritta (gia senza spazi esterni)
     */
    private void salvaParola(String categoriaRichiesta, String parola) {
        String risposta;
        synchronized (Gioco.class) {
            String categoria = categoriaValida(categoriaRichiesta);
            if (categoria == null) {
                risposta = "[Gioco] Categoria sconosciuta. Categorie: " + elencoCategorie();
            } else if (!roundAperto) {
                risposta = NESSUN_ROUND;
            } else if (parola.isEmpty()) {
                // Riga tipo "Citta=": il giocatore vuole svuotare la casella.
                parole.remove(categoria);
                risposta = "[Gioco] " + categoria + " svuotata.";
            } else if (Character.toUpperCase(parola.charAt(0)) != lettera) {
                // Prima lettera diversa: la parola non vale e non viene salvata.
                risposta = "[Gioco] \"" + parola + "\" non inizia con la lettera " + lettera + ": non salvata.";
            } else {
                parole.put(categoria, parola);
                risposta = "[Gioco] " + categoria + " = " + parola;
            }
        }
        // Fuori dal lock: l'invio non deve bloccare gli altri thread.
        invia(risposta);
    }

    /**
     * STOP: chiude il round per tutti, ma solo se la tabella del giocatore e
     * piena, altrimenti gli dice quali caselle mancano.
     */
    private void fermaRound() {
        String errore = null;
        synchronized (Gioco.class) {
            if (!roundAperto) {
                errore = NESSUN_ROUND;
            } else {
                // Elenco delle colonne ancora vuote, per un messaggio utile.
                List<String> vuote = new ArrayList<>();
                for (String categoria : CATEGORIE) {
                    if (parole.getOrDefault(categoria, "").isEmpty()) {
                        vuote.add(categoria);
                    }
                }
                if (!vuote.isEmpty()) {
                    errore = "[Gioco] Per dire STOP devi riempire tutte le caselle. Mancano: "
                            + String.join(", ", vuote);
                }
            }
        }
        if (errore != null) {
            invia(errore);
            return;
        }
        // Tabella completa: il round si chiude per tutti e partono i punteggi.
        chiudiRound(nome);
    }

    /**
     * Il primo giocatore sceglie le categorie, prima di avviare la partita.
     * Formato: "CATEGORIE Nomi,Cose,Citta".
     *
     * @param riga comando completo scritto dal client
     */
    private void impostaCategorie(String riga) {
        String errore = null;
        List<String> nuove = new ArrayList<>();
        // Si tengono solo le voci non vuote e senza doppioni.
        for (String pezzo : riga.substring("CATEGORIE".length()).split(",")) {
            String categoria = pezzo.trim();
            if (!categoria.isEmpty() && !nuove.contains(categoria)) {
                nuove.add(categoria);
            }
        }

        synchronized (Gioco.class) {
            if (!sonoHost()) {
                errore = "[Gioco] Solo il primo giocatore puo scegliere le categorie.";
            } else if (partitaAvviata) {
                // Cambiarle a partita in corso cambierebbe le colonne a meta.
                errore = "[Gioco] La partita e gia in corso: le categorie si scelgono prima di START.";
            } else if (nuove.size() < MIN_CATEGORIE || nuove.size() > MAX_CATEGORIE) {
                errore = "[Gioco] Servono da " + MIN_CATEGORIE + " a " + MAX_CATEGORIE
                        + " categorie separate da virgola, esempio: CATEGORIE Nomi,Cose,Citta,Animali";
            } else {
                CATEGORIE.clear();
                CATEGORIE.addAll(nuove);
            }
        }

        if (errore != null) {
            invia(errore);
            return;
        }
        trasmetti("[Gioco] Categorie scelte: " + elencoCategorie());
    }

    /** Il primo giocatore fa partire la partita (solo con almeno due giocatori). */
    private void avviaPartita() {
        String errore = null;
        synchronized (Gioco.class) {
            if (!sonoHost()) {
                errore = "[Gioco] Solo il primo giocatore puo avviare la partita.";
            } else if (partitaAvviata) {
                errore = "[Gioco] La partita e gia in corso.";
            } else if (GIOCATORI.size() < MIN_GIOCATORI) {
                errore = "[Gioco] Servono almeno " + MIN_GIOCATORI + " giocatori: attendi che si colleghi un altro.";
            } else {
                // Nuova partita: si riparte da zero con round, lettere e punti.
                partitaAvviata = true;
                roundCorrente = 0;
                lettereUsate = "";
                for (Gioco giocatore : GIOCATORI) {
                    giocatore.punti = 0;
                }
            }
        }

        if (errore != null) {
            invia(errore);
            return;
        }
        trasmetti("[Gioco] Partita avviata: " + ROUND_TOTALI + " round da " + DURATA_ROUND
                + " secondi, categorie " + elencoCategorie() + ".");
        avviaRound();
    }

    /**
     * Estrae la lettera, svuota le tabelle e apre un nuovo round per tutti,
     * armando il timer che lo chiudera allo scadere del tempo.
     */
    private static void avviaRound() {
        String apertura;
        synchronized (Gioco.class) {
            // Puo essere chiamato dal timer dopo la pausa: se nel frattempo la
            // partita e finita o non c'e piu nessuno, non si fa nulla.
            if (!partitaAvviata || GIOCATORI.isEmpty()) {
                return;
            }
            roundCorrente++;
            lettera = estraiLettera();
            for (Gioco giocatore : GIOCATORI) {
                giocatore.parole.clear();
            }
            roundAperto = true;
            fineRound = System.currentTimeMillis() + DURATA_ROUND * 1000L;
            // Timer di sicurezza: se nessuno dice STOP, il round si chiude da solo.
            avviaTimer(() -> chiudiRound(null), DURATA_ROUND);

            // Righe pensate per essere lette anche da una futura interfaccia grafica.
            apertura = "ROUND " + roundCorrente + "/" + ROUND_TOTALI + NL
                    + "LETTERA " + lettera + NL
                    + "TEMPO " + DURATA_ROUND;
        }
        trasmetti(apertura);
    }

    /**
     * Lettera non ancora usata in questa partita; quando l'alfabeto e finito
     * si riparte da capo.
     *
     * @return lettera estratta, maiuscola
     */
    private static char estraiLettera() {
        if (lettereUsate.length() >= ALFABETO.length) {
            lettereUsate = "";
        }
        char scelta;
        // Ripete l'estrazione finche non esce una lettera mai vista.
        do {
            scelta = ALFABETO[(int) (Math.random() * ALFABETO.length)];
        } while (lettereUsate.indexOf(scelta) >= 0);
        lettereUsate += scelta;
        return scelta;
    }

    /**
     * Esegue l'azione fra i secondi indicati, sostituendo il timer precedente.
     * Un timer annullato viene interrotto mentre dorme e non fa nulla.
     *
     * @param azione  cosa eseguire allo scadere
     * @param secondi attesa in secondi
     */
    private static void avviaTimer(Runnable azione, int secondi) {
        annullaTimer();
        timer = new Thread(() -> {
            try {
                Thread.sleep(secondi * 1000L);
            } catch (InterruptedException e) {
                return;   // il round si e chiuso prima: nessuna azione
            }
            azione.run();
        }, "timer-gioco");
        // Daemon: un timer in attesa non tiene vivo il server.
        timer.setDaemon(true);
        timer.start();
    }

    /** Ferma il timer in corso (round o pausa fra i round); va chiamato con il lock. */
    private static void annullaTimer() {
        if (timer != null) {
            timer.interrupt();
            timer = null;
        }
    }

    // ------------------------------------------------------------------
    // Chiusura del round: confronto delle risposte e punteggi
    // ------------------------------------------------------------------

    /**
     * Chiude il round (STOP di un giocatore o tempo scaduto), assegna i punti e
     * rimanda a tutti il riepilogo; se la partita e finita manda la classifica.
     *
     * @param chiHaFermato nome di chi ha scritto STOP, oppure null se e scaduto il tempo
     */
    private static void chiudiRound(String chiHaFermato) {
        String apertura;
        String rapporto;
        String finale = null;

        synchronized (Gioco.class) {
            if (!roundAperto) {
                return;   // gia chiuso: STOP e timer arrivati insieme
            }
            roundAperto = false;
            // Il timer non serve piu: se e ancora in pausa, si sveglia e basta.
            annullaTimer();

            apertura = chiHaFermato == null
                    ? "[Gioco] Tempo scaduto: il round e chiuso."
                    : "[Gioco] STOP di " + chiHaFermato + ": il round e chiuso.";

            StringBuilder testo = new StringBuilder();
            testo.append("=== Round ").append(roundCorrente).append('/').append(ROUND_TOTALI)
                    .append(" (lettera ").append(lettera).append(") ===").append(NL);

            // Una riga per giocatore, con i punti di ogni casella e il totale del round.
            for (Gioco giocatore : GIOCATORI) {
                StringBuilder riga = new StringBuilder("- ").append(giocatore.nome).append(':');
                int puntiRound = 0;
                for (String categoria : CATEGORIE) {
                    String parola = giocatore.parole.getOrDefault(categoria, "");
                    int puntiCella = 0;
                    if (parolaValida(parola)) {
                        // Unica: nessun altro l'ha scritta. Altrimenti vale meno.
                        puntiCella = occorrenze(categoria, parola) == 1
                                ? PUNTI_PAROLA_UNICA
                                : PUNTI_PAROLA_CONDIVISA;
                    }
                    giocatore.punti += puntiCella;
                    puntiRound += puntiCella;
                    riga.append(' ').append(categoria).append('=')
                            .append(parola.isEmpty() ? "-" : parola)
                            .append('(').append(puntiCella).append(')');
                }
                testo.append(riga).append(" -> ").append(puntiRound).append(" punti").append(NL);
            }
            testo.append(classificaTesto());

            if (roundCorrente >= ROUND_TOTALI) {
                // Ultimo round: la partita si chiude, i punti restano per la classifica.
                partitaAvviata = false;
                finale = "[Gioco] Partita finita! Il primo giocatore puo scrivere START per giocare ancora.";
            } else {
                // Pausa per leggere i risultati, poi parte il round successivo.
                avviaTimer(Gioco::avviaRound, PAUSA_FRA_ROUND);
            }
            rapporto = testo.toString();
        }

        // Fuori dal lock: l'invio non deve bloccare gli altri thread.
        trasmetti(apertura);
        trasmetti(rapporto);
        if (finale != null) {
            trasmetti(finale);
        }
    }

    /**
     * Quanti giocatori hanno scritto la stessa parola in quella categoria.
     * Serve per capire se una parola e unica (1) o condivisa (piu di 1).
     *
     * @param categoria colonna considerata
     * @param parola    parola da cercare
     * @return numero di giocatori con la stessa parola, senza badare alle maiuscole
     */
    private static int occorrenze(String categoria, String parola) {
        int quante = 0;
        for (Gioco giocatore : GIOCATORI) {
            String scritta = giocatore.parole.getOrDefault(categoria, "");
            if (parolaValida(scritta) && scritta.equalsIgnoreCase(parola)) {
                quante++;
            }
        }
        return quante;
    }

    /**
     * True se la parola non e vuota e comincia con la lettera del round.
     *
     * @param parola parola da controllare
     * @return true se la parola vale
     */
    private static boolean parolaValida(String parola) {
        return !parola.isEmpty() && Character.toUpperCase(parola.charAt(0)) == lettera;
    }

    /**
     * Nome esatto della categoria richiesta, o null se non esiste.
     * Il confronto ignora le maiuscole, cosi "nomi" e "Nomi" funzionano uguale.
     *
     * @param richiesta nome scritto dal client
     * @return nome della colonna come e salvato, oppure null
     */
    private static String categoriaValida(String richiesta) {
        for (String categoria : CATEGORIE) {
            if (categoria.equalsIgnoreCase(richiesta)) {
                return categoria;
            }
        }
        return null;
    }

    /**
     * Classifica ordinata per punti, dal primo all'ultimo.
     * Va chiamata con il lock di Gioco.class gia preso.
     *
     * @return testo con una riga per giocatore
     */
    private static String classificaTesto() {
        // Copia della lista: l'ordinamento non deve toccare l'ordine di arrivo,
        // che decide chi comanda.
        List<Gioco> ordinata = new ArrayList<>(GIOCATORI);
        ordinata.sort((primo, secondo) -> Integer.compare(secondo.punti, primo.punti));

        StringBuilder testo = new StringBuilder("CLASSIFICA" + NL);
        int posizione = 1;
        for (Gioco giocatore : ordinata) {
            testo.append(posizione++).append(". ").append(giocatore.nome)
                    .append(" - ").append(giocatore.punti).append(" punti").append(NL);
        }
        return testo.toString();
    }

    // ------------------------------------------------------------------
    // Messaggi verso i client
    // ------------------------------------------------------------------

    /**
     * Rimanda il messaggio a tutti i client collegati.
     *
     * @param messaggio riga di testo da spedire
     */
    private static void trasmetti(String messaggio) {
        // Copia della lista sotto lock: l'invio avviene fuori dal lock, cosi un
        // client lento non blocca gli altri thread.
        List<Gioco> destinatari;
        synchronized (Gioco.class) {
            destinatari = new ArrayList<>(GIOCATORI);
        }
        for (Gioco giocatore : destinatari) {
            giocatore.invia(messaggio);
        }
    }

    /**
     * Invia il messaggio al client di questo thread.
     * La sincronizzazione sullo stream evita righe mescolate quando due thread
     * scrivono verso lo stesso giocatore.
     *
     * @param messaggio riga di testo da spedire
     */
    private void invia(String messaggio) {
        synchronized (output) {
            output.println(messaggio);
        }
    }

    /**
     * Righe con numero di round, lettera e tempo rimasto, se un round e aperto;
     * stringa vuota se non c'e nulla in corso.
     *
     * @return testo pronto da inviare a chi si collega a partita iniziata
     */
    private static String statoRound() {
        synchronized (Gioco.class) {
            if (!roundAperto) {
                return "";
            }
            long rimasti = (fineRound - System.currentTimeMillis()) / 1000;
            return "ROUND " + roundCorrente + "/" + ROUND_TOTALI + NL
                    + "LETTERA " + lettera + NL
                    + "TEMPO " + Math.max(0, rimasti);
        }
    }

    /**
     * Elenco delle categorie separate da virgola, per i messaggi ai client.
     *
     * @return testo tipo "Nomi, Cose, Citta"
     */
    private static String elencoCategorie() {
        synchronized (Gioco.class) {
            return String.join(", ", CATEGORIE);
        }
    }

    /**
     * True se questo client e il primo collegato, quello che comanda.
     *
     * @return true per il giocatore che puo usare START e CATEGORIE
     */
    private boolean sonoHost() {
        synchronized (Gioco.class) {
            return !GIOCATORI.isEmpty() && GIOCATORI.get(0) == this;
        }
    }

    // ------------------------------------------------------------------
    // Uscita e pulizia
    // ------------------------------------------------------------------

    /**
     * Toglie il client dalla partita e avvisa gli altri; se non resta nessuno
     * la partita viene azzerata, cosi la prossima connessione riparte pulita.
     */
    private void abbandona() {
        boolean rimosso;
        boolean nessunGiocatore;
        boolean eraHost;

        synchronized (Gioco.class) {
            eraHost = sonoHost();
            rimosso = GIOCATORI.remove(this);
            nessunGiocatore = GIOCATORI.isEmpty();
            if (nessunGiocatore) {
                // Partita azzerata: round, lettere e timer tornano allo stato iniziale.
                partitaAvviata = false;
                roundAperto = false;
                roundCorrente = 0;
                lettereUsate = "";
                annullaTimer();
            }
        }

        if (!rimosso || nessunGiocatore) {
            return;
        }
        trasmetti("[Gioco] " + nome + " ha lasciato la partita.");
        if (eraHost) {
            // Il comando passa al primo rimasto, che viene annunciato a tutti.
            String nuovoHost;
            synchronized (Gioco.class) {
                nuovoHost = GIOCATORI.get(0).nome;
            }
            trasmetti("[Gioco] " + nuovoHost + " e ora il primo giocatore.");
        }
    }

    /** Chiude la socket del client; se e gia chiusa non c'e nulla da fare. */
    private void chiudi() {
        try {
            socket.close();
        } catch (IOException e) {
            // socket gia chiusa: nulla da fare
        }
    }
}
