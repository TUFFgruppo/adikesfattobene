import java.io.*;
import java.net.*;

/**
 * Server del gioco Nomi-Cose-Citta.
 *
 * Apre una ServerSocket sulla porta 7777 dell'indirizzo di questo PC e resta in
 * ascolto: a ogni connessione affida il client a un thread di gioco
 * ({@link Gioco#avvia}), cosi i giocatori non si bloccano a vicenda e possono
 * mandare le parole in qualsiasi momento.
 *
 * Uso:  java -cp build Server
 */
public class Server {

    /**
     * Punto di ingresso: mette il server in ascolto e non termina piu
     * (il ciclo si interrompe solo per un errore o chiudendo il processo).
     *
     * @param args non usati
     */
    public static void main(String[] args){
        try(var ServerSock = new ServerSocket()){
        // Porta di ascolto e indirizzo di questo PC: l'IP stampato e lo stesso
        // che i giocatori devono digitare nel client per collegarsi.
        final int SERVERPORT = 7777;
        final String SERVERIP = InetAddress.getLocalHost().getHostAddress();
        final InetSocketAddress SERVERADDRESS = new InetSocketAddress(SERVERIP, SERVERPORT);
        ServerSock.bind(SERVERADDRESS);
        System.out.println("[Server in ascolto su " + SERVERIP + ":" + SERVERPORT + "]");

        // Un giro del ciclo = un client che si e collegato.
        while (true) {
            // accept() blocca finche non arriva un client: il server puo stare
            // fermo qui a lungo senza consumare CPU.
            Socket ClientSock = ServerSock.accept();
            System.out.println("[Connected to client: " + ClientSock.getInetAddress().getHostAddress() + "]");
            // Ogni client ha il suo thread di gioco: da qui in poi parla solo Gioco.
            // La main torna subito in accept(), quindi il server resta sempre
            // pronto ad accettare nuovi giocatori.
            Gioco.avvia(ClientSock);
        }

        } catch (IOException e){
            // Errore grave (porta occupata, permessi, rete): il server non puo
            // continuare, meglio fermarsi con un messaggio chiaro.
            throw new RuntimeException(e);
        }
    }
}
