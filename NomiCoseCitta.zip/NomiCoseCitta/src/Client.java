import java.io.*;
import java.net.*;

/**
 * Client di gioco.
 *
 * All'avvio, se esiste il file intro.mp4 (o quello passato come argomento),
 * lo riproduce come video di introduzione tramite un player esterno
 * (ffplay di ffmpeg, oppure mpv o VLC se ffplay non e installato).
 * Dopo la connessione stampa tutto quello che manda il server e rimanda al
 * server ogni riga scritta da tastiera (es. Nomi=luca, STOP, START).
 *
 * Uso:  java -cp build Client
 */
public class Client {

    /** Nome di default del file video dell'intro. */
    private static final String INTRO_PER_DEFAULT = "intro.mp4";

    /**
     * Punto di ingresso: intro, richiesta di porta e IP, connessione al server e
     * poi gioco da tastiera.
     *
     * @param args eventuale percorso del video di intro (altrimenti intro.mp4)
     */
    public static void main(String[] args){
        // try-with-resources: la socket viene chiusa da sola all'uscita.
        try(var socketCliente = new java.net.Socket()){
        // Porta locale del client. Il server non la usa per riconoscere i
        // giocatori (guarda ip e porta della connessione), ma tenerla fissa
        // aiuta a ritrovare il processo. Due client sullo stesso PC non possono
        // usarla entrambi: in quel caso va tolto il bind.
        final int PORTA_CLIENTE = 2555;
        // Permette di riavviare subito il client dopo una chiusura, senza "Address already in use".
        socketCliente.setReuseAddress(true);
        socketCliente.bind(new InetSocketAddress(InetAddress.getLocalHost().getHostAddress(), PORTA_CLIENTE));

        // Video di introduzione: mostrato prima di collegarsi al server.
        riproduciIntro(args.length > 0 ? args[0] : INTRO_PER_DEFAULT);

        //      Input da scambiare con interfaccia grafica
        // Lettura da tastiera: la prima riga e la porta del server, la seconda
        // l'IP. Un BufferedReader basta e non richiede altre librerie.
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("inserisci il port del pc");
        int portaServer = Integer.parseInt(input.readLine().trim());
        System.out.println("inserisci l'ip del pc");
        String ipServer = input.readLine().trim();

        // Connessione al server scelto.
        socketCliente.connect(new InetSocketAddress(ipServer, portaServer));
        System.out.println("Connesso al server. Scrivi un comando e premi Invio (AIUTO per l'elenco).");

        // Thread che stampa tutto quello che arriva dal server.
        avviaLettura(socketCliente);

        // Ogni riga scritta da tastiera viene mandata al server: e il protocollo
        // del gioco (START, CATEGORIE ..., Categoria=parola, STOP, AIUTO).
        PrintWriter versoServer = new PrintWriter(
                new OutputStreamWriter(socketCliente.getOutputStream(), "UTF-8"), true);
        String riga;
        while ((riga = input.readLine()) != null){
            versoServer.println(riga);
        }

        } catch (IOException e){
            // Problemi di rete o di tastiera chiusa: il client non puo giocare.
            throw new RuntimeException(e);
        }
    }

    /**
     * Legge le righe del server in un thread separato: il main resta libero di
     * leggere la tastiera, altrimenti il client non potrebbe inviare nulla
     * mentre aspetta i messaggi (lettere, riepiloghi, classifica).
     *
     * @param socketCliente socket gia collegata al server
     */
    private static void avviaLettura(Socket socketCliente) {
        Thread lettore = new Thread(() -> {
            // try-with-resources: alla chiusura del server anche questo stream
            // viene chiuso, senza lasciare risorse aperte.
            try (var dalServer = new BufferedReader(
                    new InputStreamReader(socketCliente.getInputStream(), "UTF-8"))) {
                String riga;
                // readLine() restituisce null quando il server chiude.
                while ((riga = dalServer.readLine()) != null) {
                    System.out.println(riga);
                }
                System.out.println("[Client] Il server ha chiuso la connessione.");
            } catch (IOException e) {
                System.out.println("[Client] Connessione interrotta: " + e.getMessage());
            }
        }, "lettore-server");
        // Daemon: se il main termina, questo thread non tiene vivo il processo.
        lettore.setDaemon(true);
        lettore.start();
    }

    /**
     * Riproduce il video dell'intro con un player esterno, se il file esiste.
     * Il client resta in attesa della fine del video prima di procedere.
     * Viene cercata la variabile d'ambiente INTRO_PLAYER (comando o path del
     * player, es. ffplay/mpv/vlc); se assente o non eseguibile, il client
     * prosegue senza intro. Lo script avvia-client.sh la imposta da solo.
     *
     * @param percorsoVideo file video da riprodurre
     */
    private static void riproduciIntro(String percorsoVideo) {
        File video = new File(percorsoVideo);
        // Senza file l'intro viene semplicemente saltata.
        if (!video.isFile()) {
            System.out.println("Nessun video intro trovato (" + percorsoVideo + "), proseguo senza intro.");
            return;
        }
        String player = System.getenv("INTRO_PLAYER");
        // Senza player configurato si gioca subito: l'intro e solo scenografica.
        if (player == null || player.isEmpty()) {
            System.out.println("Variabile INTRO_PLAYER non impostata: salto l'intro.");
            System.out.println("Usa lo script avvia-client.sh per configurarla automaticamente.");
            return;
        }
        try {
            // Il player viene eseguito in foreground: il client aspetta la fine del video.
            // Se il comando finisce con "ffplay" aggiunge i flag per chiudersi a fine video,
            // altrimenti il client resterebbe bloccato in attesa.
            String[] parametri;
            if (new File(player).getName().contains("ffplay")) {
                parametri = new String[]{ player, "-autoexit", "-loglevel", "quiet", percorsoVideo };
            } else {
                parametri = new String[]{ player, percorsoVideo };
            }
            Process processo = new ProcessBuilder(parametri).inheritIO().start();
            int esito = processo.waitFor();   // attende la fine della riproduzione
            System.out.println("Intro terminata (codice " + esito + ").");
        } catch (IOException e) {
            // Player mancante o non eseguibile: non e un errore di gioco.
            System.out.println("Impossibile avviare il player " + player + ": salto l'intro.");
        } catch (InterruptedException e) {
            // Il thread e stato interrotto mentre aspettava: si conserva il flag
            // e si prosegue verso la connessione.
            Thread.currentThread().interrupt();
        }
    }
}
